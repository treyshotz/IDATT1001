public class Ordbok implements java.io.Serializable{
    private final String navn;
    private Ord[] ordbok;
    private int antReg;
    private final int MAKS_ANT_ORD = 10;
    private String filnavn = "ordliste.ser";

    public Ordbok(String navn){
        this.navn = navn;

        boolean status = lesOrdBokFraFil(filnavn);

        if(!status){
            antReg = 0;
            ordbok = new Ord[MAKS_ANT_ORD];
        }
    }

    public boolean regNyttOrd(Ord ord){
        if(ordbok.length == antReg){
            return false;
        }

        for(int i=0; i<antReg; i++){
            if(ordbok[i].equals(ord)){
                return false;
            }
        }

        //Komposisjon
        ordbok[antReg] = new Ord(ord.getOrd(), ord.getDef());

        //Aggregering
        //ordbok[antReg] = ord;        

        antReg++;
        return true;
    }

    public boolean leggTilDef(String ordString, String nyDef){
        Ord ord = getOrd(ordString);

        if(ord == null){
            return false;
        }

        return ord.leggTilDef(nyDef);
    }

    public Ord[] sorter(){
        Ord[] kopi = new Ord[antReg];
        for(int i=0; i<antReg; i++){
            kopi[i] = new Ord(ordbok[i].getOrd(), ordbok[i].getDef());
        }

        if(kopi.length <= 1){
            return kopi;
        }

        //return Arrays.sort(kopi);

        for(int i=0; i<kopi.length; i++){
            int minst = i;
            for(int j = i+1; j<kopi.length; j++){
                if(kopi[minst].compareTo(kopi[j]) > 0){
                    minst = j;
                }

                //bytter
                Ord temp = kopi[i];
                kopi[i] = kopi[minst];
                kopi[minst] = temp;
            }
        }

        return kopi;    
    }

    public Ord getOrd(String ordString){
        Ord ord = null;
        for(int i=0; i<antReg; i++){
            if(ordbok[i].getOrd().equals(ordString)){
                ord = ordbok[i];
                break;
            }
        }

        return ord;
    }

    private boolean lesOrdBokFraFil(String filnavn){
        try{
            FileInputStream fis = new FileInputStream(filnavn);
            ObjectInputStream ois = new ObjectInputStream(fis);

            //Les objekt og cast til Ord[]
            Ord[] ordtabell = (Ord[]) ois.readObject();

            int counter = 0;
            for(int i=0; i<ordtabell.length; i++){
                if(ordtabell[i] != null){
                    counter++;
                }
            }

            ordbok = ordtabell;
            antReg = counter;

            ois.close();

            return true;
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
            return false;
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
            return false;
        }
        catch(IOException e){
            e.printStackTrace();
            return false;
        }
    }
}