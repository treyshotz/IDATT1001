public class Ord implements java.io.Serializable{
    //2a
    private String ord;
    private String[] def;

    //2b
    public Ord(String ord, String[] def){
        this.ord = ord;
        this.def = def;
    }

    //2c
    public String getOrd(){
        return ord;
    }

    public String[] getDef(){
        return def;
    }

    //2d
    public boolean equals(Object o){
        //Sjekk om o er et Ord objekt
        if(!(o instanceof Ord)){
            return false;
        }

        //Sjekk om referansen er lik
        if(o == this){
            return true;
        }

        //Cast objektet til et Ord
        Ord temp = (Ord) o;

        //Sjekk om ordene er like
        return this.ord.equals(temp.getOrd());
    }

    //2e
    public String toString(){
        String resultat = ord + ":\n";
        for(int i=0; i<def.length; i++){
            resultat += (i+1) + ". " + def[i] + "\n";
        }

        return resultat;
    }


    //2g
    public void utvid(){
        String[] nyDef = new String[def.length + 1];

        for(int i=0; i<def.length; i++){
            nyDef[i] = def[i];
        }

        def = nyDef;
    }

    public boolean leggTilDef(String nyDef){
        //Sjekker om nyDef allerede finnes
        for(int i=0; i<def.length; i++){
            if(def[i].equals(nyDef)){
                return false;
            }
        }

        //utvider tabell
        utvid();

        //legger til def
        def[def.length - 1] = nyDef;

        return true;
    }

    
    public int compareTo(Ord temp){
        return this.ord.compareTo(temp.getOrd());
    }
}