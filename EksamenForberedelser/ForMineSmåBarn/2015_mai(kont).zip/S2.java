
// S2.java  G.S 2015-05-07
// L�sningsforslag Konteeksamen i tdat1001 3.juni 2015 - kont
// obs ikke lagt inn komposisjon overalt det skal v�re

import static javax.swing.JOptionPane.*;
import java.io.*;

class Navn implements java.io.Serializable{
	String fnavn;
	String enavn;

	// konstrukt�r
	public Navn(String fnavn, String enavn){
		this.fnavn = fnavn;
		this.enavn = enavn;
	}

	// getmetoder
	public String getFnavn(){return fnavn;}
	public String getEnavn(){return enavn;}

	//
	public boolean equals(Navn detAndre){
		if (fnavn.equals(detAndre.getFnavn()) && enavn.equals(detAndre.getEnavn())){
			return true;
		}else return false;
	}

	// brukes til � sortere listen... - feil algoritme for fornavnsjekken -endre koden!
	public int compareTo(Navn detAndre){
		if (enavn.compareTo(detAndre.getEnavn()) < 0) return -1;
		else if(enavn.compareTo(detAndre.getEnavn()) > 0)	return 1;
		else if(enavn.compareTo(detAndre.getEnavn()) == 0){ // sjekk fornavn dersom etternavn er likt
			if (fnavn.compareTo(detAndre.getFnavn()) < 0)	return -1;
			else if(fnavn.compareTo(detAndre.getFnavn()) > 0)return 1;
		}
		return 0; // fornavn og etternavn er like
	}

	public String toString(){
		return enavn + ", " + fnavn;
	}
}

class Visitkort implements java.io.Serializable{
	Navn navn;
	int tlfmobil;
	int tlfjobb;
	String epost;

	// konstrukt�r
	public Visitkort(Navn navn, int tlfmobil, int tlfjobb, String epost){
		this.navn = navn;
		this.tlfmobil = tlfmobil;
		this.tlfjobb = tlfjobb;
		this.epost = epost;
	}

	// tilgangsmetoder
	public Navn getNavn() { return navn;}
	public int getMobil() {return tlfmobil;}
	public int getJobb(){return tlfjobb;}
	public String getEpost(){return epost;}

	public boolean equals(Object obj){
		if (this == obj) return true;
		else if (obj instanceof Visitkort){
			Visitkort vk = (Visitkort)obj;
			if (vk.getNavn().equals(getNavn())) return true; // lik dersom navn er lik
		}
		return false;
	}

	public String toString(){
		String res = navn + "\nMobiltlf: " + tlfmobil + "\nTlf jobb: " + tlfjobb;
		res+= "\nEpost: " + epost;
		return res;
	}
}


class Mobil implements java.io.Serializable{
	Visitkort[] tlfListe;
	String modell;
	int egetNr;
	int antVisitkort = 0;
	int maksAntKort;

	public Mobil (String modell, int egetNr, int maksAntKort){
		this.modell = modell;
		this.egetNr = egetNr;
		this.maksAntKort = maksAntKort;
		tlfListe = new Visitkort[maksAntKort];
	}

	// Metode for � registrere et vistikort,
	public boolean regVisitkort(Visitkort vk){
		if (vk != null && antVisitkort < maksAntKort && !sjekkRegF�r(vk)){
			tlfListe[antVisitkort] = vk;
			antVisitkort++;
			return true;
		}else return false;
	}

	private boolean sjekkRegF�r(Visitkort vk){
		for (int i=0; i<antVisitkort; i++){
			if (tlfListe[i].equals(vk)) return true;
		}
		return false;
	}


	public Visitkort[] sorter(){
		if (antVisitkort >0 && tlfListe != null){
			Visitkort[] kopi = new Visitkort[antVisitkort];
			for(int i=0; i<antVisitkort; i++){
				kopi[i] = new Visitkort(tlfListe[i].getNavn(), tlfListe[i].getMobil(), tlfListe[i].getJobb(), tlfListe[i].getEpost());
			}
			for (int start=0; start<antVisitkort; start++){
				int hittilminst = start;
				for (int i = start+1; i<antVisitkort; i++){
					if(kopi[i].getNavn().compareTo(kopi[hittilminst].getNavn())<0) hittilminst = i;
				}
				Visitkort hjelp = kopi[hittilminst];
				kopi[hittilminst] = kopi[start];
				kopi[start] = hjelp;
			}
			return kopi;
		}
		return null;
	}

	public String toString(){
		String res = modell + ", " + egetNr +"\nVisittkortliste:\n";
		for (int i=0; i<antVisitkort; i++){
			res += tlfListe[i]+"\n--------------------------\n";
		}
		return res;
	}

}

class S2 implements java.io.Serializable{

	public static Mobil lesFraFil(String filnavn) throws Exception {
		try{
			FileInputStream innstrom = new FileInputStream(filnavn);
			ObjectInputStream inn = new ObjectInputStream(innstrom);
			Mobil mobil = (Mobil)inn.readObject();  // kaster eofexception ved tom fil, FileNotFound
			inn.close();
			return mobil;
		}catch(FileNotFoundException e){
			System.out.println("fil ikke funnet!");
		}catch(EOFException e){
			System.out.println("fil funnet, men tom!");
		}
		return null;
	}

	public static boolean skrivTilFil(Mobil m, String filnavn){
		boolean ok = false;
		if (m != null){
			try{
				FileOutputStream utstrom = new FileOutputStream(filnavn); // true = append
				ObjectOutputStream ut = new ObjectOutputStream(utstrom);
				ut.writeObject(m);
				ut.close();
				ok = true;
			}catch(FileNotFoundException e){
				System.out.println("fil ikke funnet!");
			}catch(Exception e){
				System.out.println("Noe gikk galt med skriving til fil!");
			}
		}
		return ok;
	}

	public static void main(String[] args){

    	String[] muligheter = {"Ny Mobil", "Registrer visittkort", "List sortert tlfliste", "List usortert", "Avslutt"};
		final int NY_MOBIL = 0;
		final int REG_VISITKORT = 1;
		final int LIST_ALLE_SORTERT = 2;
		final int LIST_USORTERT = 3;
		final int AVSLUTT = 4;

		int valg = showOptionDialog(null, "Velg", "MOBIL", YES_NO_OPTION, INFORMATION_MESSAGE, null, muligheter, muligheter[0]);
		Mobil minMobil = null;
		final String filnavn = "mobildata.ser";
		// les eventuelle data fra fil
		try{
			minMobil = lesFraFil(filnavn);
			if (minMobil == null){ // legger inn noen testdata, her kunne en valgt � ta inn brukerinput istd
				minMobil = new Mobil("Iphone 6", 90009000, 10);
				minMobil.regVisitkort(new Visitkort(new Navn("Per", "Olsen"), 91111111,71111111, "per.olsen@olsen.com"));
				minMobil.regVisitkort(new Visitkort(new Navn("Petter", "Olsen"), 92121212,72222222, "petter.olsen@olsen.com"));
				minMobil.regVisitkort(new Visitkort(new Navn("Karin", "Olsen"), 93131313,73333333, "karin.olsen@olsen.com"));
			}
		}catch(Exception e){
			System.out.println("noe gikk galt ved lesing fra fil" + e.toString());
		}
		while (valg != AVSLUTT){

			switch (valg){
				case NY_MOBIL:
					String navn = showInputDialog("Modell: ");
					int egetnr =  Integer.parseInt(showInputDialog("Eget tlfnr: "));
					int tlflistestr =  Integer.parseInt(showInputDialog("Maks antall visittkort: "));

					int sikker = showConfirmDialog(null, "Sikker? - Du vil slette alle tidligere registrerte data");
					if (sikker == YES_OPTION)	minMobil = new Mobil(navn, egetnr, tlflistestr);
					else showMessageDialog(null, "Avbryter");

				break;
				case REG_VISITKORT:
				if (minMobil != null){
					String fnavn = showInputDialog("Fornavn: ");
					String enavn = showInputDialog("Etternavn: ");
					Navn n = new Navn(fnavn, enavn);
					int mobil = Integer.parseInt(showInputDialog("Mobilnr: " ));
					int jobbtlf = Integer.parseInt(showInputDialog("Jobbtlf: " ));
					String epost = showInputDialog("Epost: ");

					boolean ok = minMobil.regVisitkort(new Visitkort(n, mobil, jobbtlf, epost));
		 			if (ok) showMessageDialog(null, "Visitkort registrert");
					else showMessageDialog(null, "Visitkort er registrert fra f�r");
				}
				break;
				case LIST_ALLE_SORTERT:
				if (minMobil != null){
					Visitkort[] vk = minMobil.sorter();
					if (vk != null){
						String res = "";
						for (int i=0; i<vk.length; i++){
							res += vk[i] + "\n--------------------------\n";
						}
						showMessageDialog(null, res);
					}
				}
				break;
				case LIST_USORTERT:
				if (minMobil != null){
					showMessageDialog(null, minMobil);
					System.out.println(minMobil);
				}
				default: break;

			}
		valg = showOptionDialog(null,"Velg","Meny", DEFAULT_OPTION, PLAIN_MESSAGE, null, muligheter, muligheter[0]);

		}
		// skriv til fil ved avslutt
		try{
			if (minMobil != null) skrivTilFil(minMobil, filnavn);
		} catch(Exception e) {
			System.out.println("Noe gikk galt ved skriving til fil. "  + e.toString());
		}
	}

}