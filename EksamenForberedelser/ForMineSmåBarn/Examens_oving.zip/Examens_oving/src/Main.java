import static javax.swing.JOptionPane.*;

public class Main {
    public static void main(String[] args){

        if (register == null){
            register = opprettNyttRegister();   // metode som opppretter ett tomt register
        }

        String[] muligheter = {"List alle", "List matsopper", "Legg til ny", "Søk", "Avslutt"};
        final int LIST_ALLE = 0;
        final int LIST_MATSOPPER = 1;
        final int REG_SOPP = 2;
        final int SOK = 3;
        final int AVSLUTT = 4;

        int valg = showOptionDialog(null, "Velg", "Eksamen des 2018",  YES_NO_OPTION,              INFORMATION_MESSAGE, null, muligheter, muligheter[0]);
        while (valg != AVSLUTT){
            switch (valg){
                case LIST_ALLE:
                    /*Anta at koden eksisterer*/
                    break;

                case LIST_MATSOPPER:
                    System.out.println(register.spiseligSoppNam().toString());
                    break;

                case REG_SOPP:
                    String navn = showInputDialog("Gjerne fyll inn et fint navn");
                    String besk = showInputDialog("Gjerne fyll inn et fint commentar");
                    boolean giftig = true;
                    int ergiftig = showConfirmDialog(null, "Er den ikke spiselig?");
                    if(ergiftig == 0) {
                        giftig = true;
                    } else {
                        giftig = false;
                    }
                    if(register.registrerSoppart(navn, besk, giftig)){
                        System.out.println("Den er registrert");
                    }else{
                        System.out.println("Den ble ikke registrert");
                    }
                    break;

                case SOK:
                    String sok = showInputDialog("Gjerne fyll inn et fint navn");
                    System.out.println(register.Sok(sok));
                    break;

                default: break;
            }
            valg = showOptionDialog(null, "Velg", "Eksamen des 2018", YES_NO_OPTION, INFORMATION_MESSAGE, null, muligheter, muligheter[0]);
        }
        skrivRegTilfil(filnavn,register);
    }
}
