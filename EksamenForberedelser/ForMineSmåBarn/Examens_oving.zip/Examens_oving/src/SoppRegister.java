import java.util.ArrayList;

/**
 * masse javadoc, fyll inn med fantasien din
 */

public class SoppRegister {
    private ArrayList<Soppart> soppartListe;


    public SoppRegister(ArrayList<Soppart> soppartListe) {
        this.soppartListe = soppartListe;
    }
    public SoppRegister() {
        this.soppartListe = new ArrayList<>();
    }

    public boolean registrerSoppart(String navn, String beskrivelse, boolean giftig){
/*        for (Soppart soppart: soppartListe) {
            if(soppart.equals(sopp)){
                return false;
            }
        }*/
        // Sjekker om soppen er registert fra før av ved hjelp av equals metoden i soppart.
        if(soppartListe.contains(new Soppart(navn, beskrivelse, giftig))) {
            return false;
        } else {
            soppartListe.add(new Soppart(navn, beskrivelse, giftig));
            return true;
        }
    }

    public ArrayList<Soppart> spiseligSoppNam(){
        ArrayList<Soppart> spislig = new ArrayList<>();
        if(soppartListe.size() == 0){
            return spislig;
        }
        for (Soppart s: soppartListe) {
            if(!s.isGIFTIG()){
                spislig.add(new Soppart(s.getNAVN(), s.getBESKRIVELSE(), s.isGIFTIG()));
            }
        }
        return spislig;
    }

    public String Sok(String sokeStreng) {
        String s = "";
        for (Soppart sopp: soppartListe) {
            if(sopp.sokIBeskrivelse1(sokeStreng)){
                s+= s.toString();
            }
        }
        return s;
    }
    public String toString(){
        String s = "Alle registrerte Sopparter (Navn Beskrivelse Spiselig):\n";
        for (int i = 0; i < soppartListe.size(); i++) {
            //int nummer = s.getIndex() + 1;
            s += (i+1) + soppartListe.get(i).toString();
        }
        return s;
    }
}
