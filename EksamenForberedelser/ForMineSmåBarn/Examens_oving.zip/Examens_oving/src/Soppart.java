/**
 * Klassen Soppart er en sopp?, den kan være giftig eller ikke, hvem vet?
 * @author Zenjjim
 * @version v1.0.0
 */

public class Soppart {

    private final String NAVN;
    private final String BESKRIVELSE;
    private final boolean GIFTIG;

    /**
     *
     * @param navn: String, navnet på sopparten
     * @param beskrivelse: String, beskrivelsen til sopp
     * @param giftig: boolean, kan du ikke spise den
     */

    public Soppart(String navn, String beskrivelse, boolean giftig){
        if(navn.isEmpty() || beskrivelse.isEmpty()){
            throw new IllegalArgumentException("Skriv inn navn og bskrivelse");
        }
        this.NAVN = navn;
        this.BESKRIVELSE = beskrivelse;
        this.GIFTIG = giftig;
    }

    /**
     *
     * @param soppart
     */
    public Soppart(Soppart soppart){
        if(soppart.getNAVN().isEmpty() || soppart.getBESKRIVELSE().isEmpty()){
            throw new IllegalArgumentException("Skriv inn navn og bskrivelse");
        }
        this.NAVN = soppart.getNAVN();
        this.BESKRIVELSE = soppart.getBESKRIVELSE();
        this.GIFTIG = soppart.isGIFTIG();
    }

    public String getNAVN() {
        return NAVN;
    }

    public String getBESKRIVELSE() {
        return BESKRIVELSE;
    }

    /**
     *
     * @return boolean, om den er giftig eller ikke
     */
    public boolean isGIFTIG() {
        return GIFTIG;
    }

    /**
     *
     * @param o objekt som skal være en soppart
     * @return om den er lik denne
     */
    @Override
    public boolean equals(Object o){
        if(!(o instanceof Soppart)){
            return false;
        }
        if(this == o) {
            return true;
        }
        Soppart soppart = (Soppart) o;

        return soppart.getNAVN().equals(this.NAVN);
    }

    public boolean sokIBeskrivelse1(String sokeString) {
        return this.BESKRIVELSE.contains(sokeString);
    }
    public boolean sokIBeskrivelse2(String sokeString) {
        return this.BESKRIVELSE.equals(sokeString);
    }
    public boolean sokIBeksrivelse3(String sokeString) {
        int sokeLen = sokeString.length();
        for (int i = 0; i < this.BESKRIVELSE.length()-sokeLen; i++) {
            if (this.BESKRIVELSE.substring(i, i+sokeLen).equals(sokeString)){
                return true;
            }
        }
        return false;
    }

    /**
     *
     * @return v(90grader til høyre)3 beste metoden i verden :)
     */
    public String toString(){
        String output = this.NAVN + " " + this.BESKRIVELSE + " ";
        if(this.GIFTIG){
            output += "Giftig\n";
        }else{
            output += "Matsopp\n";
        }
        return output;
    }
}
